import axios from "axios"

export default axios.create({
     baseURL : "http://65.20.73.28:8090//"
})