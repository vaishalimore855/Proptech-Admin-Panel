import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import http from "../BaseUrl/baseurl";
import axios from "axios";


const token = localStorage.getItem("token");
export const getAgentList = createAsyncThunk("getAgentList", async () => {
  const response = await axios.get(`http://65.20.73.28:8090/api/agents/`
  ,{
    headers: {
      authorization:token }
  });
  console.log("agent list Response", response);
  return response.data;
});

  
  export const getInterestList = createAsyncThunk("getInterestList", async (type) => {
    const response = await axios.get(`http://65.20.73.28:8090/api/agents/getintrestlist`,{
      headers: {
        authorization:token }
    });
    console.log("agent interest list Response", response);
    return response.data.data;
  });

 
  export const getKyc = createAsyncThunk("getKyc", async (id) => {
    const response = await axios.get(`http://65.20.73.28:8090/api/agents/getKyc/${id}`,{
      headers: {
        authorization:token }
    });
    console.log("get kyc Response", response.data);
    return response.data;
  });

export const getAgentbyId = createAsyncThunk("getAgentbyId", async (id) => {
  const response = await axios.get(
    `http://65.20.73.28:8090/api/agents/${id}`,{
      headers: {
        authorization:token }
    });
  console.log("agent id resp", response.data);
  return response.data;
});

const AgentSlice = createSlice({
  name: "agent",

  initialState: {
    kycData:{},
    Agents: [],
    InterestList:[],
    Agent: {},
    KycUserid: {},
    KycData: {},
    status: "",
    error: "",
  },

extraReducers(builder) {
  
  builder
    .addCase(getAgentList.pending, (state, action) => {
      state.status = "loading";
    })
    .addCase(getAgentList.fulfilled, (state, action) => {
      state.status = "succeeded";
      state.Agents = action.payload;
    })
    .addCase(getAgentList.rejected, (state, action) => {
      state.status = "failed";
      state.error = action.error.message;
    })


    .addCase(getInterestList.pending, (state, action) => {
        state.status = "loading";
      })
      .addCase(getInterestList.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.InterestList = action.payload;
      })
      .addCase(getInterestList.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
    .addCase(getAgentbyId.pending, (state, action) => {
      state.status = "loading";
    })
    .addCase(getAgentbyId.fulfilled, (state, action) => {
      state.status = "succeeded";
      state.Agent = action.payload;
    })
    .addCase(getAgentbyId.rejected, (state, action) => {
      state.status = "failed";
      state.error = action.error.message;
    })
    .addCase(getKyc.pending, (state, action) => {
      state.status = "loading";
    })
    .addCase(getKyc.fulfilled, (state, action) => {
      state.status = "succeeded";
      state.kycData = action.payload;
    })
    .addCase(getKyc.rejected, (state, action) => {
      state.status = "failed";
      state.error = action.error.message;
    });

},
});

export default AgentSlice.reducer;

