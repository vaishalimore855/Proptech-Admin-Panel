import React, { useRef } from 'react';
import { pdf } from '@react-pdf-viewer';

const DownloadPDF = () => {
  const imageRef = useRef(null);

  const downloadAsPDF = () => {
    const imgElement = imageRef.current;
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');

    canvas.width = imgElement.width;
    canvas.height = imgElement.height;

    // Draw the image onto the canvas
    context.drawImage(imgElement, 0, 0);

    // Get the base64-encoded image data
    const imageData = canvas.toDataURL('image/png');

    // Create a PDF document with the image data
    const doc = new pdf({ data: imageData });

    // Save the document
    doc.save('image.pdf');
  };

  return (
    <div>
      <h2>Download Image as PDF</h2>
      <img
        ref={imageRef}
        src="https://via.placeholder.com/150"
        alt="Sample Image"
        onLoad={() => downloadAsPDF()} // Trigger download when the image is loaded
        style={{ display: 'none' }}
      />
      <p>
        <a href="#" onClick={(e) => e.preventDefault()}>
          Download PDF
        </a>
      </p>
    </div>
  );
};

export default DownloadPDF;
