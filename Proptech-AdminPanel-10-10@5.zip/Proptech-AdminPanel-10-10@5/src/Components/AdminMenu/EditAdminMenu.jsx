import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getAdminMenuId } from "../../Redux/Slice/MenuSlice";
import { useNavigate } from "react-router-dom";

const EditAdminMenu = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const token = localStorage.getItem("token");
  const dispatch = useDispatch();
  const adminMenuId = useSelector((state) => state.adminMenu.AdminMenuId);

  const [formErrors, setFormErrors] = useState({});
  const [editedAdminmenu, setEditedAdminmenu] = useState({
    name: "",
    icon: "",
    link: "",
    priority: "",
    parentid: "",
    type: "",
  });

  useEffect(() => {
    dispatch(getAdminMenuId(id));
  }, [dispatch, id]);

  useEffect(() => {
    if (adminMenuId) {
      setEditedAdminmenu({
        name: adminMenuId.name,
        icon: adminMenuId.icon,
        link: adminMenuId.link,
        priority: adminMenuId.priority,
        parentid: adminMenuId.parentid,
        type: adminMenuId.type,
      });
    }
  }, [adminMenuId]);

  const validate = (editedAdminmenu) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    const onlyLetters = /^[A-Za-z]+$/;

    if (!editedAdminmenu.name) {
      errors.name = "Name cannot be blank";
    } else if (!onlyLetters.test(editedAdminmenu.name)) {
      errors.name = "Name should only contain letters.";
    }

    if (!editedAdminmenu.link) {
      errors.link = "Link cannot be blank";
    } else if (!onlyLetters.test(editedAdminmenu.link)) {
      errors.link = "Link should only contain letters.";
    }

    if (!editedAdminmenu.icon) {
      errors.icon = "Icon cannot be blank";
    }

    if (!editedAdminmenu.priority) {
      errors.priority = "Priority cannot be blank";
    }

    if (!editedAdminmenu.type) {
      errors.type = "Type cannot be blank";
    } else if (!onlyLetters.test(editedAdminmenu.type)) {
      errors.type = "Type should only contain letters.";
    }

    return errors;
  };

  const handleChangeEditAdminmenuInput = (e) => {
    const { name, value } = e.target;
    setEditedAdminmenu((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleEditAdminmenu = async () => {
    const data = {
      method: "PUT",
      body: JSON.stringify(editedAdminmenu),
      headers: {
        "Content-Type": "application/json",
        authorization: token,
      },
    };

    try {
      const response = await fetch(
        `http://65.20.73.28:8090/api/adminmenus/${id}`,
        data
      );
      const responseData = await response.json();

      if (responseData.status === true) {
        toast.success(responseData.message);
        navigate("/adminmenu"); 
      } else {
        toast.error(responseData.message);
      }
      navigate("/adminmenu");
    } catch (error) {
      console.error("Error updating admin menu:", error);
      toast.error("An error occurred while updating the admin menu.");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = validate(editedAdminmenu);
    setFormErrors(errors);

    if (Object.keys(errors).length === 0) {
      handleEditAdminmenu();
    }
  };

  return (
    <div>
      <div id="main">
        <div className="main-content">
          <div className="container">
            <ToastContainer />
            <div className="page-header mt-5">
              <h4>Edit Admin Menu</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage" style={{ fontSize: "16px" }}>
                      Home
                    </Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#" style={{ fontSize: "16px" }}>
                      Privilege
                    </Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="/AdminMenu" style={{ fontSize: "16px" }}>
                      Edit Admin Menu
                    </Link>
                  </li>
                  <li
                    className="breadcrumb-item active"
                    aria-current="page"
                    style={{ fontSize: "16px" }}
                  >
                    Edit Menu
                  </li>
                </ol>
              </nav>
            </div>
            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <form onSubmit={handleSubmit}>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label htmlFor="validationCustom01"> Name </label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Enter Your Name"
                            name="name"
                            value={editedAdminmenu.name}
                            onChange={handleChangeEditAdminmenuInput}
                          />
                          <p style={{ color: "red" }}>{formErrors.name}</p>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label htmlFor="validationCustom02">Link</label>
                          <input
                            type="text"
                            data-input-mask="phone"
                            className="form-control"
                            placeholder="Enter Path"
                            name="link"
                            value={editedAdminmenu.link}
                            onChange={handleChangeEditAdminmenuInput}
                          />
                          <p style={{ color: "red" }}>{formErrors.link}</p>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label htmlFor="validationCustom04">Icon</label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Enter Icon"
                            name="icon"
                            value={editedAdminmenu.icon}
                            onChange={handleChangeEditAdminmenuInput}
                          />
                          <p style={{ color: "red" }}>{formErrors.icon}</p>
                        </div>

                        <div className="col-md-6 mb-3">
                          <label htmlFor="validationCustom04">Parent Id</label>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="Enter Menu Id"
                            name="parentid"
                            value={editedAdminmenu.parentid}
                            onChange={handleChangeEditAdminmenuInput}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label htmlFor="validationCustom04">Priority</label>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="Enter priority for menu item"
                            name="priority"
                            value={editedAdminmenu.priority}
                            onChange={handleChangeEditAdminmenuInput}
                          />
                          <p style={{ color: "red" }}>{formErrors.priority}</p>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label htmlFor="validationCustom04">Type</label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Enter Menu Type"
                            name="type"
                            value={editedAdminmenu.type}
                            onChange={handleChangeEditAdminmenuInput}
                          />
                          <p style={{ color: "red" }}>{formErrors.type}</p>
                        </div>
                      </div>
                      <button
                        className="btn btn-primary mt-2"
                        type="submit"
                      >
                        Submit
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditAdminMenu;
